import { Component, OnInit } from '@angular/core';
import { Employee, Httpclientservice } from '../httpclient.service';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {

  employee: Employee = new Employee('', '', '', '');


  constructor( private httpClientService: Httpclientservice) { }

  ngOnInit(): void {
  }
    createEmployee(): void {
    this.httpClientService.createEmployee(this.employee)
        .subscribe( data => {
          this. employee = new Employee('', '', '', '');

          alert(data.name + ' Your Message Send successfully.');
          console.log('employee' + data);
        });
      }

}
