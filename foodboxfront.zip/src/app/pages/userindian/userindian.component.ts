import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userindian',
  templateUrl: './userindian.component.html',
  styleUrls: ['./userindian.component.css']
})
export class UserindianComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
