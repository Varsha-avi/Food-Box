import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserindianComponent } from './userindian.component';

describe('UserindianComponent', () => {
  let component: UserindianComponent;
  let fixture: ComponentFixture<UserindianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserindianComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserindianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
