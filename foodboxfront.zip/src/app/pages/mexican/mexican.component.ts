import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mexican',
  templateUrl: './mexican.component.html',
  styleUrls: ['./mexican.component.css']
})
export class MexicanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
