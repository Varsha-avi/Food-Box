import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-italian',
  templateUrl: './italian.component.html',
  styleUrls: ['./italian.component.css']
})
export class ItalianComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
