import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chinese',
  templateUrl: './chinese.component.html',
  styleUrls: ['./chinese.component.css']
})
export class ChineseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
