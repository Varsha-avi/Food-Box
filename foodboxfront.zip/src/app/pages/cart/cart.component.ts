import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent{

  title = 'food';
  public categories = ['Select a Category', 'Indian', 'Chinese', 'Maxican','Italian'];
  public  indian = ['Select Indian','Dosa', 'Idli', 'Poori'];
  public chinese = ['Select Chinese', 'Chicken_Nodles','Veg_Momos'];
  public maxican = ['Select Maxican', 'Cochinta_Phibil', 'Tocos'];
  public italian =['Select  Italian','Lasangae']
  public data = [
   {Name: 'Dosa', Price: 100, Photo: '../../../assets/cart/Dosa.jpg'},
   {Name: 'Idli', Price: 80, Photo: '../../../assets/cart/idli.webp'},
   {Name: 'Poori', Price: 150, Photo: '../../../assets/cart/poori.jpg'},
   {Name: 'Chicken_Nodles', Price: 250, Photo: '../../../assets/cart/cochinita.jpg'},
   {Name: 'Veg_Momos', Price: 1000.44, Photo: '../../../assets/cart/veg.jpg'},
   {Name: 'Cochinta_phibil', Price: 400.44, Photo: '../../../assets/cart/Dosa.jpg'},
   {Name: 'Tocos', Price: 300.00, Photo: '../../../assets/cart/Tacos.jpg'},
   {Name: 'Lasangae', Price: 300.00, Photo: '../../../assets/cart/lasangae.png'}
  ];
  public products:any = [];
  public selectedCategoryName = 'Select a Category';
  public selectedProductName:any;
  public searchResults:any = [];
  public searchedProduct:any = {
    Name:'',
    Price:0,
    Photo:''
  };
  public cartItems:any = [];
  public cartItemsCount = 0;
  public showCart = false;
  public GetCartItemsCount(){
    this.cartItemsCount = this.cartItems.length;
  }
  public OnCategoryChange(){
    switch(this.selectedCategoryName)
    {
      case 'Indian':
        this.products = this.indian;
        break;
      case 'Chinese':
        this.products = this.chinese;
        break;
      case 'Maxican':
        this.products = this.maxican;
        break;
      case 'Italian':
          this.products= this.italian;
          break;
      default:
        this.products = ['Select a Category'];
        break;
    }
  }
  public onProductChanged(){
      this.searchResults = this.data.filter(x=>x.Name==this.selectedProductName);
      this.searchedProduct = {
        Name: this.searchResults[0].Name,
        Price: this.searchResults[0].Price,
        Photo: this.searchResults[0].Photo
      };
  }
  public AddToCartClick() {
     this.cartItems.push(this.searchedProduct);
     alert('Item Added to Cart');
     this.GetCartItemsCount();
  }
  public ToggleCartDisplay() {
    this.showCart = (this.showCart==false)?true:false;
  }
  public DeleteCartItem(index:any){
     let confirmDelete = confirm('Are you sure, want to Delete?');
     if(confirmDelete==true) {
       this.cartItems.splice(index, 1);
       this.GetCartItemsCount();
     }
  }
}
