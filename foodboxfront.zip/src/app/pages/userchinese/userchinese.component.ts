import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userchinese',
  templateUrl: './userchinese.component.html',
  styleUrls: ['./userchinese.component.css']
})
export class UserchineseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
