import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserchineseComponent } from './userchinese.component';

describe('UserchineseComponent', () => {
  let component: UserchineseComponent;
  let fixture: ComponentFixture<UserchineseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserchineseComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserchineseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
