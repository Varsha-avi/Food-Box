import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export class Employee {
  constructor(
    public name: string,
    public email: string,
    public phone: String,
    public message: string
  ) { }
}

@Injectable({
  providedIn: 'root'
})
export class Httpclientservice {
  constructor(
    private httpClient: HttpClient
  ) {
  }

  getEmployees() {}
  public createEmployee(employee: any) {
    return this.httpClient.post<Employee>('http://localhost:8066/user' + '/' + 'addemployee', employee);
  }
}



