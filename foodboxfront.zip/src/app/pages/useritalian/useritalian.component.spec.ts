import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UseritalianComponent } from './useritalian.component';

describe('UseritalianComponent', () => {
  let component: UseritalianComponent;
  let fixture: ComponentFixture<UseritalianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UseritalianComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UseritalianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
