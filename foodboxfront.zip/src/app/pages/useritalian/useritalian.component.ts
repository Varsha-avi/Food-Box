import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-useritalian',
  templateUrl: './useritalian.component.html',
  styleUrls: ['./useritalian.component.css']
})
export class UseritalianComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
