import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usermexican',
  templateUrl: './usermexican.component.html',
  styleUrls: ['./usermexican.component.css']
})
export class UsermexicanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
