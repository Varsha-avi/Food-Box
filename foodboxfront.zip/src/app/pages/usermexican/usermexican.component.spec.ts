import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsermexicanComponent } from './usermexican.component';

describe('UsermexicanComponent', () => {
  let component: UsermexicanComponent;
  let fixture: ComponentFixture<UsermexicanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsermexicanComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UsermexicanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
