import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indian',
  templateUrl: './indian.component.html',
  styleUrls: ['./indian.component.css']
})
export class IndianComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
