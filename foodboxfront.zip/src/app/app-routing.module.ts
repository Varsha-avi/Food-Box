import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './pages/aboutus/aboutus.component';
import { DashboardComponent } from './pages/admin/dashboard/dashboard.component';
import { CartComponent } from './pages/cart/cart.component';
import { ChineseComponent } from './pages/chinese/chinese.component';
import { ContactusComponent } from './pages/contactus/contactus.component';

import { HomeComponent } from './pages/home/home.component';
import { IndianComponent } from './pages/indian/indian.component';
import { ItalianComponent } from './pages/italian/italian.component';
import { LoginComponent } from './pages/login/login.component';
import { MexicanComponent } from './pages/mexican/mexican.component';
import { SignupComponent } from './pages/signup/signup.component';

import { UserDashboardComponent } from './pages/user/user-dashboard/user-dashboard.component';
import { UserchineseComponent } from './pages/userchinese/userchinese.component';
import { UserindianComponent } from './pages/userindian/userindian.component';
import { UseritalianComponent } from './pages/useritalian/useritalian.component';
import { UsermexicanComponent } from './pages/usermexican/usermexican.component';

import { AdminGuard } from './services/admin.guard';
import { NormalGuard } from './services/normal.guard';


const routes: Routes = [

  {
    path:'',
    component: HomeComponent,
    pathMatch: 'full',
  },

  {
    path:'signup',
    component:SignupComponent,
    pathMatch:'full',
  },
  {
    path:'login',
    component:LoginComponent,
    pathMatch:'full',
  },

  {
    path:'admin',
    component:DashboardComponent,
   

    children:[
      {
        path:'indian',
        component:IndianComponent,
       
      },
      {
        path:'mexican',
        component:MexicanComponent,
        
      },
      {
        path:'chinese',
        component:ChineseComponent,
       
      },
      {
        path:'italian',
        component:ItalianComponent,
        
      },
    ],
    canActivate:[AdminGuard],
    
  },

  {
    path:'user',
    component:UserDashboardComponent,
    
    children:[
      {
        path:'userindian',
        component:UserindianComponent,
       
      },
      {
        path:'usermexican',
        component:UsermexicanComponent,
        
      },
      {
        path:'userchinese',
        component:UserchineseComponent,
       
      },
      {
        path:'useritalian',
        component:UseritalianComponent,
        
      },
      {
        path:'aboutus',
        component:AboutusComponent,
        
      },
      {
        path:'cart',
        component:CartComponent,
        
      },
      {
        path:'contactus',
        component:ContactusComponent,
        
      },
    ],
    canActivate:[NormalGuard],

  },
    
] 


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
