package com.foodbox.model;



import javax.persistence.Entity;
import javax.persistence.Id;


import lombok.Data;



@Data
@Entity

public class Contact {
	
@Id	
public String name;
public String email;
public String phone;
public String message;

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getmessage() {
	return message;
}
public void setPassword(String message) {
	this.message = message;
}
public Contact(String name, String email,String phone, String message,String department,
		String employeetype) {
	super();
	this.name = name;
	this.phone = phone;
	this.email = email;
	this.message = message;
}
public Contact() {
	super();
}
}
