package com.foodbox.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foodbox.model.Contact;
import com.foodbox.repo.ContactRepository;

@Service
public class ContactService {
@Autowired
	public ContactRepository EmpRepo;
	public List<Contact> getAllEmployees() {

		return EmpRepo.findAll();
	}
	public Contact saveEmployee(Contact contact) {
       contact=EmpRepo.save(contact);
		return contact;
	}

}
