package com.foodbox.service;

import java.util.Set;

import com.foodbox.model.User;
import com.foodbox.model.UserRole;

public interface UserService {

	
	// for Creating user
	
	public User createUser(User user, Set<UserRole> userRoles) throws Exception;
	
	// for getting user
	
	public User getUser(String username);
	
	// for deleting id
	
	public void deleteUser(Long userId);
	
	
	
}
